#!/usr/bin/env python3

import collections
import dataclasses
import logging
import typing as t

from pathlib import Path

from src.labels_helpers import is_pipeline_dir_versioned

from src.pipeline_ids import generate_pipeline_id

from src.scanners.context_scan import ScanContext
from src.scanners.context_target import TargetContext, SeenTargets
from src.scanners.create_context_target import create_context_target

from src.types.labels import Labels
from src.types.std_vars_pipeline import PipelineStandardVars
from src.types.template_pipeline import PIPELINE_TEMPLATE_FILE

from src.utils.file_utils import config_file_exists

from src.vars.std_vars import (
    make_spinnaker_app_name,
    make_global_spinnaker_pipeline_name,
    make_spinnaker_pipeline_name,
)

WILL_NEVER_EXIST = {
    "k8s",
    "k8s_integrations",
    "identitypipelines",
}

# The global logger used in this module
_logger = logging.getLogger(__name__)


class InvalidSpinnakerPipeline(Exception):
    """
    Thrown if the given pipeline does not exits in given Spinnaker application.
    """

    pass


@dataclasses.dataclass(frozen=True)
class JinjaPipelineHelper():
    """
    Jinja Helper methods for pipeline templates.
    """

    dry_run: bool
    """
    Indicates whether Spinnaker applications/pipelines should be created
    or updated.
    """

    pipeline_std_vars: PipelineStandardVars
    """
    The standard pipeline template variables corresponding
    to the current target being processed by the current
    pipeline template.
    """

    seen_targets: SeenTargets
    """
    Passed from scan_context
    """

    calling_pipeline: TargetContext
    """
    The calling pipeline target.
    """

    pipeline_repo: str
    """
    Path to sfcd/spinnaker repo
    """

    scan_context: ScanContext

    child_dependent_pipelines: t.Dict[
        str, t.Dict[                           # team level
            str, t.Dict[                       # app level
                str, t.Dict[                   # pipeline level
                    str, t.Set[TargetContext]  # template level
                ]
            ]
        ]
    ] = dataclasses.field(
        default_factory=lambda: collections.defaultdict(
            lambda: collections.defaultdict(
                lambda: collections.defaultdict(
                    lambda: collections.defaultdict(set)
                )
            )
        ),
    )
    """
    The list of all dependent pipeline templates captured by the
    get_dependent_spinnaker_pipeline_id() function.

    NOTE: This is a map keyed by the corresponding team directory name,
          application directory name, pipeline directory name, and finally
          pipeline template name.

          The leaf is a set of TargetContexts.
    """

    external_pipelines: t.Dict[str, t.Set[str]] = dataclasses.field(
        default_factory=lambda: collections.defaultdict(set),
    )
    """
    List of all external pipelines referenced by the templates, in the form
    of <spinnaker_app_name>/<spinnaker_pipeline_name>
    """

    child_multiple_pipelines_in_dir: t.Dict[
        str, t.Dict[str, t.Dict[str, t.Set[str]]]] = (
        dataclasses.field(
            default_factory=lambda: collections.defaultdict(
                lambda: collections.defaultdict(
                    lambda: collections.defaultdict(set),
                ),
            ),
        )
    )
    """
    The list of all dependent pipeline templates captured by the
    get_dependent_spinnaker_pipeline_id() function when the template_name field
    is provided. This is to support the usecase where there can be multiple
    pipelines per directory.

    NOTE: This is a map keyed by the corresponding team directory name and
          the corresponding application directory name and the pipeline
          directory name. The leaf value is a set of all the dependent pipeline
          templates names present in the pipeline directory.
    """

    force_versioning: bool = False
    labels_user: t.Optional[Labels] = None
    downstream_label: t.Optional[str] = None

    """
    Versioned aka labeled pipelines are created with a public facing label, marked external here,
    (e.g. 'latest', 'stable'), and an internal checksum label. Provide both here, as we will use
    them to calculate pipeline IDs, if versioning is in use.
    """

    def get_spinnaker_pipeline_id(
        self,
        spinnaker_app_name: str,
        spinnaker_pipeline_name: str,
        func_string: t.Optional[str] = None,
        optional: bool = False,
        child_label: t.Optional[str] = None
    ) -> str:
        """
        Retrieves the pipeline ID for the given pipeline from Spinnaker.

        :param spinnaker_app_name: The name of Spinnaker application
        :type spinnaker_app_name: str

        :param spinnaker_pipeline_name: The name of Spinnaker pipeline
        :type spinnaker_pipeline_name: str

        :param optional: Whether this dependent pipeline is required.
        :type optional: bool

        :return: The pipeline ID from Spinnaker
        :rtype: str

        :raises InvalidSpinnakerPipeline: If the given pipeline does not exist
                                          in Spinnaker or does not have
                                          a valid pipeline ID
        """

        if func_string is None:
            self.external_pipelines["{}/{}".format(spinnaker_app_name, spinnaker_pipeline_name)].add(
                "/{}/{}/{}".format(
                    self.calling_pipeline.pipeline.team,
                    self.calling_pipeline.pipeline.application,
                    self.calling_pipeline.pipeline.name,
                )
            )

            func_string = "sfcd.get_spinnaker_pipeline_id('{}','{}'".format(
                spinnaker_app_name,
                spinnaker_pipeline_name,
            )
            if optional:
                func_string += ",optional={}".format(optional)
            func_string += ")"

        # get the pipeline ID

        pipeline_id = generate_pipeline_id(
            self.pipeline_repo,
            self.scan_context.spinnaker_instance,
            spinnaker_app_name,
            spinnaker_pipeline_name,
            child_label,
            strip_label_from_name=True,
        )

        # if we couldn't generate a pipeline id, something is wrong

        if pipeline_id is None:
            message = (
                "ERROR: In template {}/{}/{}, unable to determine pipeline ID for child pipeline {},{}".format(
                    self.calling_pipeline.pipeline.team,
                    self.calling_pipeline.pipeline.application,
                    self.calling_pipeline.pipeline.name,
                    spinnaker_app_name,
                    spinnaker_pipeline_name,
                )
            )
            if self.dry_run:
                self.scan_context.add_validation_error(
                    self.calling_pipeline.pipeline.team,
                    self.calling_pipeline.pipeline.application,
                    self.calling_pipeline.pipeline.name,
                    message=message,
                )
            else:
                raise InvalidSpinnakerPipeline(message)

        # if this is a dry_run, we return a placeholder for later

        if self.dry_run:
            # Use the function string, which gets turned into a helper call in
            # the pre-compiled templates. Go ahead and add the trailing '}}',
            # also, which requires double-adding to escape them.
            return "FAKE_PIPELINE_ID-{}-FAKE_PIPELINE_ID".format(func_string)

        assert(pipeline_id is not None)
        return pipeline_id

    def get_dependent_spinnaker_pipeline_id(
        self,
        team_name: str,
        application_name: str,
        pipeline_name: str,
        falcon_instance: str,
        functional_domain: str,
        cell: t.Optional[str],
        service_instance_id: str,
        optional: bool = False,
    ) -> t.Optional[str]:
        """
        Wrapper for _get_dependent_spinnaker_pipeline_id, which
        retrieves the pipeline ID from Spinnaker corresponding to the given
        pipeline template and the given target.

        Catches InvalidSpinnakerPipeline and returns None if optional is True.

        :param team_name: The name of team directory
        :type team_name: str

        :param application_name: The name of application directory
        :type application_name: str

        :param pipeline_name: The name of pipeline directory
        :type pipeline_name: str

        :param falcon_instance: The name of the target Falcon instance
        :type falcon_instance: str

        :param functional_domain: The name of the target functional domain
        :type functional_domain: str

        :param cell: The name of the target cell, if any
        :type cell: Optional[str]

        :param service_instance_id: The ID of the target service instance
        :type service_instance_id: str

        :param optional: Whether this dependent pipeline is required.
        :type optional: bool
        """
        try:
            return self._get_dependent_spinnaker_pipeline_id(
                team_name,
                application_name,
                pipeline_name,
                falcon_instance,
                functional_domain,
                cell,
                service_instance_id,
                optional,
            )
        except InvalidSpinnakerPipeline:
            if not optional:
                raise
            return None

    def get_dependent_falcon_global_spinnaker_pipeline_id(
        self,
        team_name: str,
        application_name: str,
        pipeline_name: str,
        use_cells: bool,
        falcon_instance: str,
        functional_domain: str = "NONE",
        cell: t.Optional[str] = None,
        optional: bool = False,
    ) -> t.Optional[str]:
        if cell is not None:
            if cell.strip() == "":
                cell = None

        if use_cells and cell is None:
            cell = "NONE"

        # Create func string
        func_name = "sfcd.get_dependent_falcon_global_spinnaker_pipeline_id"
        func_string = "{}('{}','{}','{}',{},'{}','{}'".format(
            func_name,
            team_name,
            application_name,
            pipeline_name,
            use_cells,
            falcon_instance,
            functional_domain,
        )
        if cell:
            func_string += ",cell='{}'".format(cell)
        else:
            func_string += ",None"
        if optional:
            func_string += ",optional={}".format(optional)
        func_string += ")"

        try:
            validate_falcon_global_targets(
                falcon_instance,
                functional_domain,
                cell,
            )
            return self._get_dependent_spinnaker_pipeline_id(
                team_name,
                application_name,
                pipeline_name,
                falcon_instance,
                functional_domain,
                cell,
                "NONE",
                optional,
                func_string=func_string
            )
        except InvalidSpinnakerPipeline:
            if not optional:
                raise
            return None

    def _get_dependent_spinnaker_pipeline_id(
        self,
        team_name: str,
        application_name: str,
        pipeline_name: str,
        falcon_instance: str,
        functional_domain: str,
        cell: t.Optional[str],
        service_instance_id: str,
        optional: bool = False,
        func_string: str = "",
    ) -> t.Optional[str]:
        """
        Retrieves the pipeline ID from Spinnaker corresponding to the given
        pipeline template and the given target.

        NOTE: This function guarantees that the specified pipeline template
              is processed before retrieving the pipeline ID from Spinnaker.
              If the specified pipeline template has not been processed yet,
              it will be processed recursively directly from this function.
              If there is a dependency loop of any arbitrary depth, it will be
              detected and this function will generate an exception.
        """
        if cell is not None:
            if cell.strip() == "" or cell.lower() == "none":
                cell = None

        if not func_string:
            func_name = "sfcd.get_dependent_spinnaker_pipeline_id"
            func_string = "{}('{}','{}','{}','{}','{}'".format(
                func_name,
                team_name,
                application_name,
                pipeline_name,
                falcon_instance,
                functional_domain,
            )
            if cell:
                func_string += ",cell='{}'".format(cell)
            else:
                func_string += ",None"
            func_string += ",service_instance_id='{}'".format(service_instance_id)
            if optional:
                func_string += ",optional={}".format(optional)
            func_string += ")"

        # Generate names of the corresponding application/pipeline in Spinnaker
        spinnaker_app_name = self.get_spinnaker_application_name(
            team_name,
            application_name,
        )

        spinnaker_pipeline_name = self.get_spinnaker_pipeline_name(
            pipeline_name,
            falcon_instance,
            functional_domain,
            cell,
            service_instance_id,
        )

        # Do not add pipeline as target if config file does not exist
        config_path: t.Tuple[str, ...] = (
            team_name,
            application_name,
            pipeline_name,
            "config.json"
        )
        if optional and not config_file_exists(self.pipeline_repo, config_path):
            raise InvalidSpinnakerPipeline(
                f"Child pipeline '{'/'.join(config_path[:-1])}' config file does "
                f"not exist."
            )

        # Capture the name of this pipeline as a child dependent pipeline
        # NOTE: pipeline template name is always pipeline.j2 for non globals
        self.child_dependent_pipelines[team_name][application_name][pipeline_name][PIPELINE_TEMPLATE_FILE].add(
            create_context_target(
                team_name,
                application_name,
                pipeline_name,
                None,
                falcon_instance,
                functional_domain,
                cell,
                service_instance_id,
                False,
                "INFERRED",
                optional=optional,
            ),
        )

        # This is the second pass, get the real pipeline ID from Spinnaker
        child_label: t.Optional[str] = None
        if (
            self.force_versioning or
            is_pipeline_dir_versioned(self.labels_user, team_name, application_name, pipeline_name)
        ):
            if self.downstream_label is None:
                child_label = 'stable'
            else:
                child_label = self.downstream_label

        return self.get_spinnaker_pipeline_id(
            spinnaker_app_name,
            spinnaker_pipeline_name,
            func_string=func_string,
            optional=optional,
            child_label=child_label,
        )

    def get_dependent_global_spinnaker_pipeline_id(
        self,
        team_name: str,
        application_name: str,
        pipeline_dir: str,
        template_name: t.Optional[str] = None,
        optional: bool = False,
    ) -> t.Optional[str]:
        """
        Wrapper for _get_dependent_global_spinnaker_pipeline_id which
        retrieves the pipeline ID from Spinnaker corresponding to the given
        global pipeline template.

        Catches InvalidSpinnakerPipeline and returns None if optional is True.

        :param team_name: The name of team directory
        :type team_name: str

        :param application_name: The name of application directory
        :type application_name: str

        :param pipeline_dir: The name of pipeline directory
        :type pipeline_dir: str

        :param template_name: The name of template in a pipeline directory.
                              This is used in cases where multiple pipelines
                              per directory can exist
        :type template_name: str

        :param service_instance_id: The ID of the target service instance
        :type service_instance_id: str

        :param optional: Whether this dependent pipeline is required.
        :type optional: bool

        :return: The Spinnaker pipeline id corresponding to the pipeline
                 associated with the input parameters
        :rtype: t.Optional[str]
        """
        try:
            return self._get_dependent_global_spinnaker_pipeline_id(
                team_name,
                application_name,
                pipeline_dir,
                template_name,
                optional,
            )
        except InvalidSpinnakerPipeline:
            if not optional:
                raise
            return None

    def _get_dependent_global_spinnaker_pipeline_id(
        self,
        team_name: str,
        application_name: str,
        pipeline_dir: str,
        template_name: t.Optional[str] = None,
        optional: bool = False,
    ) -> t.Optional[str]:
        """
        Retrieves the pipeline ID from Spinnaker corresponding to the given
        global pipeline template.

        NOTE: This function guarantees that the specified pipeline template
              is processed before retrieving the pipeline ID from Spinnaker.
              If the specified pipeline template has not been processed yet,
              it will be processed recursively directly from this function.
              If there is a dependency loop of any arbitrary depth, it will be
              detected and this function will generate an exception.
        """
        func_string = "sfcd.get_dependent_global_spinnaker_pipeline_id('{}','{}','{}'".format(
            team_name,
            application_name,
            pipeline_dir,
        )
        if template_name:
            func_string += ",template_name='{}'".format(template_name)
        if optional:
            func_string += ",optional={}".format(optional)
        func_string += ")"

        # Generate names of the corresponding application/pipeline in Spinnaker
        spinnaker_app_name = self.get_spinnaker_application_name(
            team_name,
            application_name,
        )

        spinnaker_pipeline_name = self.get_global_spinnaker_pipeline_name(
            pipeline_dir,
            template_name
        )

        # Do not add pipeline as target if config file does not exist
        config_path: t.Tuple[str, ...] = (
            team_name,
            application_name,
            pipeline_dir,
            "config.json"
        )
        if optional and not config_file_exists(self.pipeline_repo, config_path):
            raise InvalidSpinnakerPipeline(
                f"Child pipeline ({config_path[:-1]}) config file does "
                f"not exist."
            )

        # Capture the name of this pipeline as a child dependent pipeline
        pipeline_template_name = template_name if template_name else PIPELINE_TEMPLATE_FILE
        self.child_dependent_pipelines[team_name][application_name][pipeline_dir][pipeline_template_name].add(
            create_context_target(
                team_name,
                application_name,
                pipeline_dir,
                template_name,
                None,
                None,
                None,
                None,
                True,
                "INFERRED",
                optional=optional,
            ),
        )

        if template_name is not None:
            if template_name:
                self.child_multiple_pipelines_in_dir[team_name][
                    application_name
                ][
                    pipeline_dir
                ].add(template_name)

        # This is the second pass, get the real pipeline ID from Spinnaker
        child_label: t.Optional[str] = None
        if (
            self.force_versioning or
            is_pipeline_dir_versioned(self.labels_user, team_name, application_name, pipeline_dir)
        ):
            if self.downstream_label is None:
                child_label = 'stable'
            else:
                child_label = self.downstream_label

        return self.get_spinnaker_pipeline_id(
            spinnaker_app_name,
            spinnaker_pipeline_name,
            func_string=func_string,
            child_label=child_label,
        )

    def get_spinnaker_application_name(
        self,
        team_name: str,
        application_name: str,
    ) -> str:
        """
        Returns the name of the Spinnaker application corresponding
        to the given application template.

        :param team_name: The name of team directory
        :type team_name: str

        :param application_name: The name of application directory
        :type application_name: str

        :return: The corresponding Spinnaker application name
        :rtype: str
        """
        return make_spinnaker_app_name(team_name, application_name)

    def get_spinnaker_pipeline_name(
        self,
        pipeline_name: str,
        falcon_instance: str,
        functional_domain: str,
        cell: t.Optional[str],
        service_instance_id: str,
        label: t.Optional[str] = None,
    ) -> str:
        """
        Returns the name of the Spinnaker pipeline corresponding
        to the given pipeline template and the given target.

        :param pipeline_name: The name of pipeline directory
        :type pipeline_name: str

        :param falcon_instance: The name of the target Falcon instance
        :type falcon_instance: str

        :param functional_domain: The name of the target functional domain
        :type functional_domain: str

        :param cell: The name of the target cell, if any
        :type cell: Optional[str]

        :param service_instance_id: The ID of the target service instance
        :type service_instance_id: str

        :return: The corresponding Spinnaker pipeline name
        :rtype: str
        """
        if cell is not None:
            if cell.strip() == "":
                cell = None

        return make_spinnaker_pipeline_name(
            pipeline_name,
            falcon_instance,
            functional_domain,
            cell,
            service_instance_id,
            label=label,
        )

    def get_global_spinnaker_pipeline_name(
        self,
        pipeline_name: str,
        template_name: t.Optional[str] = None,
        label: t.Optional[str] = None,
    ) -> str:
        """
        Returns the name of the global Spinnaker pipeline corresponding
        to the given pipeline template.

        :param template_name: needed for supporting multiple pipelines per
                              directory
        :type template_name: str

        :param pipeline_name: The name of pipeline directory
        :type pipeline_name: str

        :return: The corresponding Spinnaker pipeline name
        :rtype: str
        """

        # remove the extension of the dependent pipeline and add it to the
        # pipeline directory name
        computed_pipeline_name: str = (
            f"{Path(template_name).stem}-{pipeline_name}" if (
                template_name is not None and template_name
            ) else pipeline_name
        )

        return make_global_spinnaker_pipeline_name(computed_pipeline_name, label=label)

    def get_trigger_id(self, trigger_name: str) -> str:
        """
        Generates a globally unique trigger ID for the current
        application/pipeline in Spinnaker.

        NOTE: This function is guaranteed to be stable, namely,
              it always generates the same trigger ID for the same
              trigger name regardless of how many times it is called
              for the same trigger name. And conversely, this function
              is guaranteed to generate different trigger IDs for
              different trigger names.

        :param trigger_name: The logical name of the trigger
        :type: trigger_name: str

        :return: The trigger ID as a string
        :rtype: str
        """
        return "trigger-{}-{}-{}".format(
            self.pipeline_std_vars.std.app.spinnaker_app_name,
            self.pipeline_std_vars.std.pipeline.spinnaker_pipeline_name,
            trigger_name,
        )

    def get_artifact_id(self, artifact_name: str) -> str:
        """
        Generates a globally unique artifact ID for the current
        application/pipeline in Spinnaker.

        NOTE: This function is guaranteed to be stable, namely,
              it always generates the same artifact ID for the same
              artifact name regardless of how many times it is called
              for the same artifact name. And conversely, this function
              is guaranteed to generate different artifact IDs for
              different artifact names.

        :param artifact_name: The logical name of the artifact
        :type artifact_name: str

        :return: The artifact ID as a string
        :rtype: str
        """
        return "artifact-{}-{}-{}".format(
            self.pipeline_std_vars.std.app.spinnaker_app_name,
            self.pipeline_std_vars.std.pipeline.spinnaker_pipeline_name,
            artifact_name,
        )


def validate_falcon_global_targets(
    falcon_instance: str,
    domain: str,
    cell: t.Optional[str],
) -> None:
    """
    Confirms the set of fire targets defined for a partial global pipeline
    are valid.

    To be valid, all defined targets must also have defined parents. E.g.
    if a cell is defined then domain and falcon_instance must also be
    defined.
    """
    # Domain must be defined if a cell as been defined
    if (cell is not None and cell != "NONE") and domain == "NONE":
        raise InvalidSpinnakerPipeline("Domain is required if cell is defined")

    # Falcon must be defined if a domain has been defined
    if domain != "NONE" and falcon_instance == "NONE":
        raise InvalidSpinnakerPipeline(
                "Falcon instance is required if domain is defined"
        )
